/**
* Package for inheritance shapes.
*
* @author (Ashraf)
* @version 1.0
*/
package uk.ac.aston.oop.inheritance.shapes;